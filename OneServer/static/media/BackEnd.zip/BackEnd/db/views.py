from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from db.models import KeyWord,User
from db.serializers import KeyWordSerializer, UserSerializer
from django.shortcuts import render

@csrf_exempt
def keyword_list(request):
    """
    List all code keyword, or create a new snippet.
    """
    if request.method == 'GET':
        keyword = KeyWord.objects.all()
        serializer = KeyWordSerializer(keyword, many=True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = KeyWordSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def keyword_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        snippet = KeyWord.objects.get(pk=pk)
    except KeyWord.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = KeyWordSerializer(snippet)
        return JsonResponse(serializer.data)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = KeyWordSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)

@csrf_exempt
def user_list(request):
    """
    List all code keyword, or create a new snippet.
    """
    if request.method == 'GET':
        user = User.objects.all()
        serializer = UserSerializer(user, many=True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = UserSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def user_login(request):
    """
    List all code keyword, or create a new snippet.
    """
    if True:
        data = JSONParser().parse(request)
        usr_name=data['usr_name']
        try:
            snippet = User.objects.get(usr_name=usr_name)
        except User.DoesNotExist:
            return HttpResponse(status=404)
        serializer = UserSerializer(snippet)
        return JsonResponse(serializer.data)

@csrf_exempt
def user_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        snippet = User.objects.get(pk=pk)
    except User.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = UserSerializer(snippet)
        return JsonResponse(serializer.data)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = UserSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)

def index(request):
    return render(request, 'index.html')