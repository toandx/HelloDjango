from django.urls import path
from db import views

urlpatterns = [
    path('keyword/', views.keyword_list),
    path('keyword/<int:pk>/', views.keyword_detail),
    path('user/', views.user_list),
    path('user/<int:pk>/', views.user_detail),
    path('login/', views.user_login),
    path('index/', views.index),
]